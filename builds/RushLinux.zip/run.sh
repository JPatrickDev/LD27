#!/bin/sh
java -Djava.library.path="linux/" -jar Rush.jar